#!/bin/sh
#
# Sophos Anti-Virus SAVi daemon for Unix installation script Version 1.04
# Copyright (c) 2006-2015 Sophos Ltd, Oxford, England
#
# --------------------------------------------------------------------------
#	DO NOT INCLUDE ANY CURLY BRACES IN ANY COMMENTS! 
#	Starting from the first line containing "----", all comments that do not
#	contain a right curly brace are removed before this file is shipped.
#

LC_ALL=C
export LC_ALL

case "$1" in
  -readytogo) ready_to_go=yes;;
  *) ready_to_go=;;
esac

#if [ "$1" = -readytogo ]; then
if [ "$ready_to_go" ]; then
   shift
else
   # restart script with proper shell, check ksh first because of HP-UX
   {
      ksh -c 'exit 0'
   } >/dev/null 2>/dev/null      && ENV= exec ksh $0 -readytogo "$@"
   {
      bash -c 'exit 0'
   } >/dev/null 2>/dev/null      && ENV= exec bash $0 -readytogo "$@"
   os=`uname -s 2>/dev/null`
   if [ "$os" != Linux ] && [ "$os" != FreeBSD ] && [ "$os" != BSDi ]; then
      echo "Error: Could not find a suitable shell (ksh or bash)"
      echo "       with which to run the installation script."
      exit 1
   fi
   {
      sh -c 'exit 0'
   } >/dev/null 2>/dev/null   && ENV= exec sh $0 -readytogo "$@"
fi

###########################
##                       ##
##  Auxillary functions  ##
##                       ##
###########################

VAcp()
{
   # value added cp - replaces all these horrible copychownmkdirchmodchgrp functions
   # cp $1 $2, if $3 is given chmod $3, if $4 given chown $4, if $5 given chgrp $5
   # inform user if verbose
   # exit if error

   # the braces are needed for the strip-comment-script not to mutilate this line
   # "Error: Internal script problem '(VAcp())'"
   [ ${#} -lt 2 ] && ferror VAcpErr

   if [ ! -d $2 ]; then
     rm -f $2
   fi

   # "Cannot copy $1 to $2"
   cp -f $1 $2 || ferror copyErr "$1" "$2"
#  fecho 1 $1 copied to $2
   if [ "$6" = "" ]; then
     fechomess 1 t "$copiedText" "$1" "$2"
   fi

   [ "$3" ] && VAchmod $3 $2
   [ "$4" ] && VAchown $4 $2
   [ "$5" ] && VAchgrp $5 $2
}

VAmv()
{
   # "Internal script problem '(VAmv())'"
   [ ${#} -ne 2 ] && ferror VAmvErr
   # "Cannot delete $2"
   rm -f $2 || ferror delErr "$2"
   # "Cannot rename $1 to $2"
   mv -f $1 $2 || ferror renErr "$1" "$2"
   # "$1 renamed to $2"
   fechomess 1 renamed "$1" "$2"
}

VAchmod()
{  # just like chmod
   # "Error: Cannot chmod $2 to $1"
   chmod $1 $2 || ferror chmodErr "$2" "$1"
}

VAchown()
{  # just like chown
   # "Error: Cannot chown $2 to $1"
   chown $1 $2 || ferror chownErr "$2" "$1"
}

VAchgrp()
{  # just like chgrp
   # "Error: Cannot chgrp $2 to $1"
   chgrp $1 $2 || ferror chgrpErr "$2" "$1"
}

VAmkdir()
{
   # mkdir $1, if $2 given chmod $2, if $3 given chown $3, if $4 given chgrp $4
   # Parameters: $1 directory name, $2 owner, $3 group, $4 permissions
   # Return: 0 on success, 1 on incorrect parameters, 2 on mkdir failure,
   #         3 on chown/chgrp/chmod failure
   # Sanity check.

   # First, make the directory if we need to.
   if [ ! -d $1 ]; then
      if mkdir -p $1 ; then
         # "Created directory $1"
         fechomess 1 createDir "$1"
      else
         # "Could not create directory $1"
         ferror createDirErr "$1"
      fi
   fi

   [ "$2" ] && VAchmod $2 $1
   [ "$3" ] && VAchown $3 $1
   [ "$4" ] && VAchgrp $4 $1
}

VAln()
{
   # ln -s $1 $2 with error handling and message
   rm -f "$2"
   if ln -s "$1" "$2" >/dev/null 2>&1; then
      # "$1" symlinked to "$2"
      fechomess 1 t "$symlinkedText" "$1" "$2"
   else
      # Error Unable to make symbolic link from "$1" to "$2."
      ferror createSymLinkErr "$1" "$2"
   fi
}

VAexit()
{
   # tidy up and exit - this saves us from doing the same thing at several exit points
   rm -f /tmp/sav_install.$$ 
   exit $1
}

error()
{
   # echo parameters as error and exit - this will save us many a pair of braces
   fecho - 'Error:  ' $*
   VAexit 1
}

# There have been some changes to the way text is output.
#
# To cope with localisation, new functions allow you to output 
# text by referring to a message label; this message label is then got from
# the appropriate language file, so it can be used in multiple languages.
# For instance, instead of using fecho 1 "Does not exist", you might write
# fechomess 1 Does_not_exit instead, and the code would take care of looking up
# the appropriate message in whatever language you're using.  No, I'm not going
# to translate that into French, German, Spanish,etc.
#
# The new routines which have been added are:-
#
# ferror    - output message label as error and exit.  Message must contain
#             'Error:' or equivalent at the start
# substargs - substitute % arguments in text for ones passed to substargs
# getmess   - look for named message in appropriate language file, and
#             put it into $output, for use by other routines.
# printmess - output message label in appropriate language to screen
#             NO PARAMETER SUBSITUTION WITH printmess.  USE fechomess for this.
# fechomess - output message label via fecho in appropriate language.
#             Messages (for ferror and fechomess only) may have $ parameters,
#             e.g. $1, $2, and these are substituted for.  For example,
#             fechomess fredText "tom" "harry", where the label [[fredText]]
#             was "fred plus $1 and $2" would
#             output the text "fred plus tom and harry"
#
# Note that all these new routines (except substargs) take what we call a
# message label as their parameter.  A message label is a tag by which the
# actual message we want is denoted, in the language file, surrounded by
# [[ and ]].  For example, the language file might contain:
# [[fred]]       followed by the line:
# This is some text.
# If you used any of these functions and gave them fred as parameter, you
# would get the text "This is some text".
#
########
#
# New error message which takes a message label as $1 and outputs message
# from text file via fechomess.
#
ferror()
{
   # echo parameters as error and exit - this will save us many a pair of braces
   fechomess _ $*
   VAexit 1
}

########

# substargs - this routine is used to substitute arguments in text, e.g. %1,
# %2, %3, etc. by the actual arguments $2, $3 which have been passed to
# this routine.  (Note: $1 being the text that is passed to this routine
# itself).  E.g. if you pass the string "fred %1 and %2" plus "tom" and "bill",
# you will get the string "fred tom and bill" placed in $output.
# We don't bother to substitute anything beyond argument 3, as none of the
# text uses more than %2.  If this changes, it's quite easy to extend th
# seds and add in an extra one or two.
#
substargs()
{
  output=`echo "$1" | sed -e "s?\%1?$2?g" | sed -e "s?\%2?$3?g"`
}

########

# getmess extracts a message from a file full of messages.
# The file format should be something like:
# [[MessageName]]
# Text of message...
# More message text...
# [[NextMessage]]
# ...
# [[End]]
#
# Parameter 1 ($1) = the message label (name).
# Returns:           $output equals actual text, no parameters substituted.
# Note: the message text will be put into $output for subsequent use.
#
getmess()
{
  # Arg 1 is the message label.  Save it in $mess
  mess=$1

  this_language_file=$language_file

  # Look for start of specified message.  If we can't find it, complain!
  grep -l "\[\[$mess\]\]" $this_language_file > /dev/null
  if [ $? -ne 0 ]; then
    # Couldn't find message... in this language file.  So try default
    # (English) messages and use that.
    if [ "$this_language_file" = "$default_lang_file" ]; then
      error "Could not locate message '$mess' in '$this_language_file'"
      err_loading_messages=yes
      exit 1
    fi
    this_language_file=$default_lang_file
    grep -l "\[\[$mess\]\]" $this_language_file > /dev/null
    if [ $? -ne 0 ]; then
      error "Could not locate message '$mess' in either '$this_language_file' or '$default_lang_file'"
      err_loading_messages=yes
      exit 1
    fi
  fi
  if [ "$err_loading_messages" != yes ]; then
    output=`sed '1,/\[\['$1'\]\]/d;/\[\[/,$d' $this_language_file`
  fi
}

########

# printmess simply prints out the message corresponding to the message
# label passed to it.  No parameter subsitution is done at all, so this is
# must useful for outputting things like the help text.
# Parameter 1 ($1) = the message label (name).
# Returns:           $output equals actual text, no parameters substituted.
#
printmess()
{
  getmess $1
  echo "$output"
}

########

# fechomess extracts a message from a file full of messages, and then passes
# the message onto fecho for formatting and echoing.
# i.e. locate the message passed to it in as its first
# parameter, and then use fecho (not printf) to output it.
#
# This routine uses the same format as fecho, so the main parameter - the
# message label - may occur as $1, $2, or $3 (maybe even $4) - depending on
# which formatting options you have first.
#
# Er, with one exception - the t option is specific to fechomess.  Using the
# t option, you can extract the message from the file, and it just puts it
# into $output.  This is the only use of $output by fechomess; everything else
# will either send it to the screen or (if verbose is set too high) remain
# silent.
#
# l is used to specify a message which is long, and therefore may not be
# correctly formatted on the screen unless it is examined to see if it
# extends over 40 characters (Japanese characters, for instance, are displayed
# as double width screen characters).  This tells fecho to look for breaks
# when it won't fit into 40 double width characters.
#
fechomess()
{
  # If the first arg - and the second arg, maybe - are something like a
  # digit, or a + or a -, then we shift everything down.
  # we do this to ensure the first arg will always be a message label.
  firstarg=
  secondarg=
  longtext=
  text=
  qmark=
  case "$1" in
      [0-9]) firstarg=$1;
             case "$verbose" in
               [0-9]) [ $verbose -ge $firstarg ] || return;;
             esac;
             shift;;
      +) firstarg=$1; shift;; 
      -) firstarg=$1; shift;;
      _) firstarg=$1; shift;;
      l) longtext=yes; shift;;
      t) text=yes; shift;;
  esac

  case "$1" in
      [0-9]) secondarg=$1;
             case "$verbose" in
               [0-9]) [ $verbose -ge $secondarg ] || return;;
             esac;
             shift;;
      +) secondarg=$1; shift;; 
      -) secondarg=$1; shift;;
      _) firstarg=$1; shift;;
      l) longtext=yes; shift;;
      t) text=yes; shift;;
  esac

  if [ "$1" = "t" ]; then
    text=yes; shift
  fi

  if [ "$text" ]; then
    output="$1"
  else
    getmess $1
    if [ "$full_stop" ] && [ "$comma" ]; then
      output=`echo $output | sed -e "s/$full_stop/$full_stop /g" | sed -e "s/$comma/$comma /g"`
    fi
  fi

  # Substitute arguments
  shift
  substargs "$output" $*
  # See if there is a question mark in the text and eliminate it.
  echo "$output" | grep " ?" > /dev/null
  if [ $? -eq 0 ]; then
    qmark=" ?"
  else
    echo "$output" | grep \? > /dev/null
    if [ $? -eq 0 ]; then
      qmark="?"
    fi
  fi
  if [ "$qmark" ]; then
    output=`echo "$output" | sed -e "s/\?//g"`
  fi
  fecho $firstarg $secondarg $output
}

########

fecho()
{
   # formatted echo - usage: fecho [verbose] [+ | -] word word word...
   # echos words and formats as a paragraph. with appropriate line breaks. If 
   # the first word is preceded by a single plus sign, the paragraph is 
   # indented by 9 characters, if preceded by a - the indentation starts at the
   # second line. If verbose (a single digit) is given, then the message is only
   # output if $verbose is at least verbose. In other words, verbose defines the
   # verbosity level necessary for the message to be printed.
   case "$verbose,$1" in
      [0-9],[0-9]) [ $verbose -ge $1 ] || return; shift;;
   esac
   # God, this function is sexy!
   # w: current word about which it is pondered whether it will fit on current line
   # l: current line yet to be echoed, but never empty
   # p: indentation prefix
   case $1 in
      '') echo; return;;
      +) shift
         #p='         '
         p=$warning_spaces
         #l="         $1";;
         l="$warning_spaces$1";;
      -) shift
         #p='         '
         p=$warning_spaces
         l="$1";;
      _) shift
         #p='       '
         p=$error_spaces
         l="$1";;
      *) p=
         l="$1";;
   esac
   shift

   for w in "$@"
   do
      if [ "$longtext" ] && [ "$lang" = utf ]; then
        x=`echo "$l $w" | cut -c1-40`
        if [ "$x" != "$l $w" ]; then
          echo "$l"
          l="$p$w"
        else
          l="$l $w"
        fi
      else
      case "$l $w" in
      ????????????????????????????????????????????????????????????????????????????????*)
         # if current word makes line too long, put it at beginning of next one
         echo "$l"
         l="$p$w";;
      *) l="$l $w";;
      esac
      fi
   done
   echo "$l$qmark"
   qmark=
   longtext=
}

########

print_usage()
{
#   "Usage: install.sh [-h] [-v] "
#   "                  [-d <dir>] [-b <rel>] [-l <rel>] [-m <rel>] [-s <rel>]"
#   "                  [-i [<dir>] | -ni] [-ssi | -nssi] [-idc | -nidc]"
#   ""
#   "  -h        This message"
#   "  -v        Verbose operation (Recommended for first time installation)"
#   ""
#   "  -d dir    Directory prefix for the following four options (default /usr/local)"
#   "  -b dir    Binary directory            (relative to prefix, default bin)"
#   "  -l dir    Library directory           (relative to prefix, default lib)"
#   ""
#   "Example: install.sh -v -d /usr"
#   "Use install.sh with no options for a default installation in /usr/local."
#
    # Use printmess so it outputs the help text exactly as it is - otherwise
    # the spaces and so forth won't come out properly.
    printmess help1; printmess help2; printmess help3
}

########

which()
{
   # See if $1 is in the path and return error if not
   # Also echo $1 with its path, which means output needs to be dev-nulled

   # Walk the path looking for a program called $1 which is executable.
   # When one is found, bail out.
   i=$IFS # save it
   IFS=:
   for d in $PATH; do
      if [ -x $d/$1 ]; then
         echo $d/$1
         IFS=$i # Restore IFS
         return 0
      fi
   done
   IFS=$i
   return 1
}

#####################################
##                                 ##
##  Interesting stuff starts here  ##
##                                 ##
#####################################

declareInitVariables()
{  # All variables must be listed here and marked local if they are only used in one function.
   # All single letter variables are totally local, i.e. do not call a function while they are meant to stay alive.

   is32Bit=0
   is64Bit=0
   bin_install_dir="bin"            # directory for binaries, will be made absolute by scanCommandLine()
   bsd_os=no                        # set to yes if BSD type OS
   comma=                           # holds the value of a Japanese comma
   config_file=                     # full path of sav.conf
   current_dir=`pwd`                # current directory
   default_lang_file=savdi_installmsg_en.txt # Default to English language
                                             # messages
   end=                             # local to fechomess()
   eng_override=                    # -eng used to override messages to English
   err_loading_messages=            # yes if error occurred loading from file
   error_spaces='       '           # spaces output on line after "Error:"
   existence_test=-e                # the test option to check for file exists, different on HP-UX's ksh
   finalWarning=                    # local to checkPaths()
   firstarg=                        # local to fechomess()
   first_lib=                       # local to install_libsavi()
   freebsd_ver=                     # major version of FreeBSD, or unset if not FreeBSD
   full_stop=                       # holds the value of a Japanese full-stop
   got_lib="no"                     # set to yes if we have a libsavi somewhere
   ide_files=                       # local to install_vdl_files
   icheckd_conf="/etc/icheckd.conf" # 
   ide_files_keep=                  # local to install_vdl_dat
   ide_files_removed=               # local to install_vdl_dat
   inpath=                          # local to checkPaths()
   install_intercheck=              # whether or no
   install_lists=                   # whether to install IC for diskless clients
   install_prefix=/usr/local        # root installation directory
   intercheck_pid='set below'       # PID of running InterCheck server
   intercheck_root='set below'      # install directory for intercheck client files
   isLinux=                         # $platform == linux.*
   isRedHatLinux=                   # RedHat Linux
   lang=                            # Languge being used
   language_file=$default_lang_file # Default to English language messages
   localised=                       # set to yes if product is localised
   lib_install_dir="lib"            # directory for library, will be made absolute by scanCommandLine()
   libpathname=LD_LIBRARY_PATH      # name of library path variable
   libsavi=libsavi.so.3             # name of library to look for
   libssp=libssp.so.0               # name of library to look for
   mess=                            # Local to getmess, holds message label
   message_files=yes                # SWEEP and icheckd messages files used
   no_sav_conf=                     # if yes, do not update or create sav.conf
   old_suffix=                      # suffix (.dat, .vdb) of old vdl, local to copy_vdl_dir
   old_vdl_file=                    # old vdl main file name, local to copy_vdl_dir
   old_vdl_subfiles=                # vdl subfiles currently installed
   output=                          # Local to message functions, holds return
                                    #  value when we get a message
   platform=                        # code for platform we are on
   product_name=                    # descriptive name of platform
   qmark=                           # had to have one starting q!  fecho &
                                    # fechomess use this to glue on ? at end
   ready_to_go=                     # used at startup only to tell if restarted
   remove_ide_files=no              # delete IDE files
   remove_old_versions=yes          # delete old libraries and vdl files
   removelibs=                      # local to install_libsavi, libraries to
                                    #  remove
   report_help=                     # whether help text is needed
   report_host_err=                 # couldn't recognise platform
   report_incompatible=             # essentially a 64bit install on a 32 bit system
   report_icheckd_conflict=         # whether command line icheckd conflict
   report_lang_file_missing=        # if lang file couldn't be found
   report_no_messages_this_lang=    # if no messages were found for this lang
   report_unknown_option=           #
   root_user="root"                 # 
   sav5_possible=no                 # SAV 5 system?
   sav5_libs=/opt/sophos-av/lib     # Peanut default area for libsavi
   sav5_vdls=/opt/sophos-av/lib/sav # Peanut default area for virus data
   sav5_libs64=/opt/sophos-av/lib64     # Peanut default area for libsavi
   sav5_vdls64=/opt/sophos-av/lib64/sav # Peanut default area for virus data
   sav5_vdl_found=                  # if we found SAV 5 virus data
   sav_install_dir="sav"            # directory for virus data, will be made absolute by scanCommandLine()
   savid_doesnt_look_for_vdl=yes    # 
   savid_install_dir="savdi"        # directory for SAVI daemon
   scan_option=                     # the option which generated an error
   secondarg=                       # local to fechomess()
   start=                           # local to fechomess()
   tab="	" # TAB!                   # this is the only place where the tab character is used, so we know where to look if it gets lost
   text=                            # local to fechomess, means o/p to variable
   tried_language_file=             # set to the language file we tried to open
   vdl_file=                        # the vdl.* to be installed
   vdl_subfiles=                    # Virus data subfiles
   verbose=0                        # level of required verbosity
   warning_spaces='         '       # spaces output on line after "Warning:"

   # Compare $tab to space. This is in case an editor crunched
   # up the tab above, which does happen, you know.
   # Error \$tab is not the tab character.
   case $tab in *\ * | '') ferror tabErr; esac
}

########

checkParameter()
{
   # checks that $1 is a parameter (i.e. neither empty nor a switch)
   # don't give an error if $2 is 'noerror'
   if [ -z "$1" ] || [ "${1#-}" != "$1" ]; then
      [ "$2" = noerror ] && return 1
      # Error: Expected parameter to option "$1"
      ferror paramErr "$1"
   fi
}

########

scanCommandLine()
{
  err=
   while [ -n "$1" ] && [ "$err" != yes ]; do
      case "$1" in
      -d) # <sophos install prefix>
         checkParameter "$2"
         install_prefix="$2"
         shift
         ;;
      -b) # <binary directory>
         checkParameter "$2"
         bin_install_dir="$2"
         shift
         ;;
      -l ) # <library directory>
         checkParameter "$2"
         lib_install_dir="$2"
         shift
         ;;
      -sav ) # <virus data directory>
         checkParameter "$2"
         sav_install_dir="$2"
         shift
         ;;
      -s | savid | savdi ) # <SAVI daemon data directory>
         checkParameter "$2"
         savid_install_dir="$2"
         shift
         ;;
      -v) verbose=1;;

      -h )
         report_help=yes
         #print_usage
         #VAexit 0
         ;;

      -eng)
         eng_override=yes
         ;;

      -nc )
         no_sav_conf=yes
         ;;

      # unrecognized
      * )
         scan_option=$1
         report_unknown_option=yes
         err=yes
         ;;
      esac
      shift
   done

   # put the prefix in front of relative paths
   [ "${bin_install_dir##/*}" ] && bin_install_dir="${install_prefix%/}/$bin_install_dir"
   [ "${sav_install_dir##/*}" ] && sav_install_dir="${install_prefix%/}/$sav_install_dir"
   [ "${savid_install_dir##/*}" ] && savid_install_dir="${install_prefix%/}/$savid_install_dir"
   [ "${lib_install_dir##/*}" ] && lib_install_dir="${install_prefix%/}/$lib_install_dir"
}

########

detectPlatform()
{


   x=`file ./savdid | grep "32-bit"`
   is32Bit=0
   test "$x" && is32Bit=1

   x=`file ./savdid | grep "64-bit"`
   is64Bit=0
   test "$x" && is64Bit=1


   if [ $is32Bit -eq $is64Bit ]; then
      echo "Can't determine bitness of savdid"
   fi



   # Glean information about our platform
   # Set the product code depending on what we get
   case "`uname -s`,`uname -m`" in
   OSF1,alpha)
      platform=digitalunix
      product_name="Digital UNIX/Alpha"
      ;;
   SunOS,sun4*)
      platform=solaris.sparc
      product_name="Solaris/SPARC"
      sav5_possible=yes # I don't think it is, but there!
      ;;
   SunOS,i86pc)
      platform=solaris.intel
      product_name="Solaris/Intel"
      sav5_possible=yes # I don't think it is, but there!
      ;;
   Linux,*86_64|Linux,amd64)
      platform=linux.amd64
      product_name="Linux/AMD64"
      isLinux=yes
      sav5_possible=yes # I don't think it is, but there!
      [ $existence_test /etc/redhat-release ] && isRedHatLinux=yes
      ;;
   Linux,*86*)
      platform=linux.intel
      product_name="Linux/Intel"
      isLinux=yes
      sav5_possible=yes
      [ $existence_test /etc/redhat-release ] && isRedHatLinux=yes
      [ $existence_test /lib/libc.so.6 ] && isLibc6=yes

      if [ $is64Bit -eq 1 ]; then
          report_incompatible=yes
      fi
      ;;
   Linux,alpha)
      platform=linux.alpha
      product_name="Linux/Alpha"
      isLinux=yes
      [ $existence_test /etc/redhat-release ] && isRedHatLinux=yes
      sav5_possible=yes # I don't think it is, but there!
      ;;
   Linux,ppc*)
      platform=linux.ppc
      product_name="Linux/PowerPC"
      isLinux=yes
      sav5_possible=yes # I don't think it is, but there!
      ;;
   Linux,s390)
      platform=linux.s390
      product_name="Linux/S390"
      isLinux=yes
      sav5_possible=yes # I don't think it is, but there!
      ;;
   FreeBSD,i386)
      platform=freebsd
      product_name="FreeBSD/Intel"
      freebsd_ver=`uname -r | cut -c1`
      bsd_os=yes
      sav5_possible=yes # I don't think it is, but there!

      if [ $is64Bit -eq 1 ]; then
          report_incompatible=yes
      fi
      ;;
   Data*ONTAP*GX,i*86)
      platform=freebsd
      product_name="FreeBSD/Intel"
      freebsd_ver=`uname -r | cut -c1`
      bsd_os=yes
      ;;
   FreeBSD,amd64)
      platform=freebsd.amd64
      product_name="FreeBSD/AMD64"
      freebsd_ver=`uname -r | cut -c1`
      bsd_os=yes
      sav5_possible=yes # I don't think it is, but there!
      ;;
   Data*ONTAP*GX,amd64)
      platform=freebsd.amd64
      product_name="FreeBSD/AMD64"
      freebsd_ver=`uname -r | cut -c1`
      bsd_os=yes
      ;;
   OpenBSD,i386)
      platform=openbsd.i386
      product_name="OpenBSD/Intel"
      bsd_os=yes

      if [ $is64Bit -eq 1 ]; then
          report_incompatible=yes
      fi
      ;;
   OpenBSD,amd64)
      platform=openbsd.amd64
      product_name="OpenBSD/AMD64"
      bsd_os=yes
      ;;
   BSD/OS,i386)
      platform=bsdi
      product_name="BSDi/Intel"
      bsd_os=yes

      if [ $is64Bit -eq 1 ]; then
          report_incompatible=yes
      fi
      ;;
   AIX,*)
      platform=aix
      product_name="AIX/PowerPC"
      libpathname=LIBPATH
      ;;
   SCO_SV,i386)
      platform=scoopenserver
      product_name="SCO OpenServer/Intel"
      mandirbodge=.

      if [ $is64Bit -eq 1 ]; then
          report_incompatible=yes
      fi
      ;;
   UnixWare,i386)
      platform=scounixware
      product_name="SCO UnixWare/Intel"
      mandirbodge=.

      if [ $is64Bit -eq 1 ]; then
          report_incompatible=yes
      fi
      ;;
   OpenUNIX,i386)
      platform=scounixware
      product_name="SCO UnixWare/Intel"
      mandirbodge=.

      if [ $is64Bit -eq 1 ]; then
          report_incompatible=yes
      fi
      ;;
   HP-UX,9000*)
      platform=hpux.hppa
      product_name="HP-UX/HP-PA"
      existence_test=-a
      libpathname=SHLIB_PATH
      ;;
   HP-UX,ia64)
      platform=hpux.ia64
      product_name="HP-UX/Itanium"
      existence_test=-a
      libpathname=SHLIB_PATH
      ;;
   *)
      # Oh dear, what a shame...
      # Error Cannot determine host type.
      report_host_err=yes
   esac
}



detectCompatibility()
{
    # Relies on ldd not failing if a library is missing
    # failing only if there is an incompatibility

    ldd ./savdid 2> /dev/null > /dev/null
    if [ $? -ne 0 ]; then
        report_not_runnable=yes
    fi
}



########

detectLanguage()
{
  # It's a fatal error if we can't open the English language file, as we may
  # need to fall back on this: a) if we can't find the appropriate language
  # file for this language, and b) if we can't locate the appropriate message
  # within the language file (then we fall back on English and try to locate
  # the English message.
  if [ ! -r $default_lang_file ]; then
     error Could not open English language message file $language_file.  Check you have unpacked the distribution correctly.
  fi

  lang=en
  language_file=$default_lang_file

  # If we are outputting messages in English (by override), then we don't need
  # to bother with checking for the appropriate language & message file.
  if [ ! "$eng_override" ]; then

    # Note that we are only localised for Linux intel libc6 systems.
    # And Solaris intel and SPARC.
    # I'm not 100% sure this test for Linux libc6 is completely foolproof,
    # but we will have to see how it goes...!
    case $platform in
    solaris.intel|solaris.sparc) localised=yes;;
    linux.intel) [ "$isLibc6" ] && localised=yes
                 ;;
    linux.amd64) localised=yes;;
    *) localised=;;
    esac

    localised= # disable localisation for now

    gotlang=

    if [ "$localised" ]; then
      # See if we recognise the language we are using
      if [ "$LANG" = "" ]; then
        lang=en
      else
        if [ $platform = solaris.intel ] || [ $platform = solaris.sparc ]; then
          case "$LANG" in
            ja_JP.UTF-8) lang=utf; gotlang=yes;;
            # Fixme #1774 - stop Solaris treating PCK as if it is euc.
            # We don't recognise PCK, so treat it as unrecognised.
            ja_JP.PCK*) gotlang=;;
            ja*) lang=euc; gotlang=yes;;
          esac
        elif [ $platform = linux.intel ] || [ $platform = linux.amd64 ]; then
          case "$LANG" in
            # Fixme 1662 - UTF-8 added (this is really for Peanut).
            ja_JP.utf8) lang=utf; gotlang=yes;;
            ja_JP.UTF-8) lang=utf; gotlang=yes;;
            ja*) lang=euc; gotlang=yes;;
          esac
        fi
         
        if [ ! "$gotlang" ]; then
          case "$LANG" in
            en | en_* | C | POSIX) lang=en;;
            fr | fr_* ) lang=fr;;
            de | de_* ) lang=de;;
            ja_JP.eucJP ) lang=euc;;
            es | es_* ) lang=es;;
            it | it_* ) lang=it;;
            #pt_BR | pt_br ) lang=pt_br;;
            #*) fecho - Warning: There are no installation messages for language $LANG - using English language messages
            # Don't recognise this language - make a note and report
            # "Warning: There are no installation messages for language $LANG - using English language messages"
            *) lang=en; report_no_messages_this_lang=yes
          esac
        fi

        language_file=savdi_installmsg_$lang.txt
        if [ "$lang" = en ]; then
          language_file=$default_lang_file
        fi
        if [ ! -r $language_file ] && [ $language_file != $default_lang_file ]; then
          tried_language_file=$language_file
          report_lang_file_missing=yes
          #fecho - Warning: Using English language messages - could not find language file $language_file.  Did you unpack the distribution correctly\?
          # Couldn't find the language file, so use the English message file
          language_file=$default_lang_file
        fi
      fi
    fi
    #echo $lang

    # The following things affect how the messages are displayed, so if we
    # couldn't find the right language file, we don't adjust any of these,
    # as it will be displaying the English messages.
    if [ "$report_lang_file_missing" != yes ]; then
    # We should now know the language, so set up language specific things,
    # like how many spaces we output to aline error messages and warnings.
    case "$lang" in
      fr ) error_spaces='         '
           warning_spaces='                ';;
      de ) error_spaces='        '
           warning_spaces='         ';;
      es ) error_spaces='       '
           warning_spaces='       ';;
      pt_br ) error_spaces='      '
              warning_spaces='       ';;
      it ) error_spaces='        '
           warning_spaces='            ';;
    # Check if we are running a Japanese language.  If so,
    # for Japanese text, in order that the stuff that splits up words works
    # properly, we read in the text for a full stop, and also comma.
    # When we see these in the messages, we replace them with an extra
    # space - this means that the message text will be split up nicely
    # and won't overflow.
       euc | utf )
         getmess full_stop
         full_stop=$output
         getmess comma
         comma=$output
         error_spaces='         '       # spaces output on line after "Error:"
         warning_spaces='       '       # spaces output on line after "Warning:"
         ;;
    esac
    fi
  fi
}

########

# Here we report errors which occurred early on and which we have "kept" back
# until we know what language we should report them in.
# This also includes the help text - well, it's not a whole lot of point
# outputting it in the wrong language, is it!
#
reportEarlyErrors()
{
  if [ "$report_unknown_option" ]; then
     fechomess Unrecognized "$scan_option"
     echo
     print_usage
     VAexit 1
  fi

  if [ "$report_host_err" ]; then
     # "Cannot determine host type."
     ferror HostErr
  fi

  if [ "$report_incompatible" ]; then
     # Incompatible installation
     ferror CompatibleErr
  fi

  if [ "$report_not_runnable" ]; then
     # Not runnable on this system
     ferror NotRunnableErr
  fi


  # This one isn't an error, it means the -eng override was used.
  if [ "$eng_override" ]; then
    fecho 1 Using English language messages
    fecho 1
  fi

  # No messages were found for this language
  if [ "$report_no_messages_this_lang" ]; then
    fecho - Warning: There are no installation messages for language $LANG - using English language messages
  fi

  if [ "$report_lang_file_missing" ]; then
     fecho - Warning: Using English language messages - could not find language file $tried_language_file.  Check you have unpacked the distribution correctly.
  fi

  if [ "$report_help" ]; then
     print_usage
     VAexit 0
  fi
}
########

doLibCheck_notFound() {
   if [ -r savdid-i ]; then
     savdid=savdid-i
   else
     savdid=savdid
   fi
   ldd 2>/dev/null $savdid | grep "$1" | grep "not found" >/dev/null
}

doLibCheck()
{
   # If we don't find them in the "obvious" place, i.e. the library
   # directory, we try the Peanut area, if we are running on Linux.
   sav5_libcheck_name=$1
   sav5_libcheck_file=$2
   
   doLibCheck_notFound $sav5_libcheck_name
   if [ $? -eq 0 ]; then
      # Couldn't find libraries.  Is the platform Linux?  Then check for
      # the Peanut place where they put the library...
      if [ "$sav5_possible" = "yes" ]; then

        # Check 64 bit locations first

        if [ -r $sav5_libs64/$libsavi -a $is64Bit -eq 1 ]; then
          fechomess 1 found_sav_linux_libs $libsavi $sav5_libs64 $lib_install
          # Ensure the library directory exists
          if [ ! -d "$lib_install_dir" ]; then
             VAmkdir "$lib_install_dir" 0755 0 0
          fi

          VAln $sav5_libs64/$libsavi $lib_install_dir/$libsavi
          ldd $savdid | grep "libsavi" | grep "not found" > /dev/null 2>/dev/null
          if [ $? -eq 0 ]; then
            fechomess - NonstandardLibrary
          fi
          
          got_lib=yes

        elif [ -r $sav5_libs/$2 -a $is32Bit -eq 1 ]; then

          # So we are using 32 bit libraries

          fechomess - found_sav_linux_libs $sav5_libcheck_file $sav5_libs $lib_install
          # Ensure the library directory exists
          if [ ! -d "$lib_install_dir" ]; then
             VAmkdir "$lib_install_dir" 0755 0 0
          fi

          VAln $sav5_libs/$sav5_libcheck_file $lib_install_dir/$sav5_libcheck_file
          doLibCheck_notFound $sav5_libcheck_name
          if [ $? -eq 0 ]; then
            fechomess - NonstandardLibrary
          fi

          got_lib=yes
          fi
        fi
      if [ "$got_lib" != "yes" ]; then
        ferror could_not_find_$sav5_libcheck_name $sav5_libcheck_file
      fi
   fi
}

doSSPLibCheck()
{
   # If we don't find them in the "obvious" place, i.e. the library
   # directory, we try the Peanut area, if we are running on Linux.
   got_ssplib=
   sav5_libcheck_name=$1
   sav5_libcheck_file=$2
   
   if [ ! -r $lib_install_dir/$libssp ]; then
      # Couldn't find libraries.  Is the platform Linux?  Then check for
      # the Peanut place where they put the library...
      if [ "$sav5_possible" = "yes" ]; then

        # Check 64 bit locations first

        if [ -r $sav5_libs64/$libsavi -a $is64Bit -eq 1 ]; then
          fechomess 1 found_sav_linux_libs $libssp $sav5_libs64 $lib_install

          VAln $sav5_libs64/$libssp $lib_install_dir/$libssp
          got_ssplib=yes

        elif [ -r $sav5_libs/$2 -a $is32Bit -eq 1 ]; then

          # So we are using 32 bit libraries

          fechomess 1 found_sav_linux_libs $sav5_libcheck_file $sav5_libs $lib_install

          VAln $sav5_libs/$libssp $lib_install_dir/$libssp
          got_ssplib=yes
        fi
      fi

      if [ "$got_ssplib" != "yes" ]; then
        fechomess 1 could_not_find_$sav5_libcheck_name $sav5_libcheck_file
      fi
   fi
}

doAllPossibleChecks()
{
   # After the parameters have been set, we can check for nearly everything that can go wrong,
   # before telling the user much about what we were going to do before an error crept up.

   # We need to locate a large number of system commands.  It is done this
   # way for several reasons.  Firstly, 'which' is not in fact built-in to
   # many shells.  Secondly, sometimes it exists on the disk but is
   # designed for the wrong shell -- this will result in the wrong information
   # being gathered.  So, we have to do it by hand, as it were.
   for c in chgrp chmod chown cmp cp cut kill ln ls mkdir mv ps rm egrep grep head pwd sed sleep tar tail; do
      # Error Could not find \'$c\' in path.
      which $c >/dev/null || ferror FindErr "$c"
   done
   
   # Ensure installation files exist
   for f in savdid; do
      # Error $f does not exist in your install directory. Did you unpack the distribution file correctly\?
      [ $existence_test $f ] || ferror MissingFile $f
   done

   # Check for secret "no sav conf" flag - this has been added for halfnut
   # If it's set, we don't create a sav.conf file
   if [ "$no_sav_conf" != "yes" ]; then
     if [ $existence_test /etc/sav.conf ]; then
        config_file=/etc/sav.conf
     elif [ $existence_test /usr/local/sav/sav.conf ]; then
        config_file=/usr/local/sav/sav.conf
     else
        config_file=
     fi
   fi

   # Check SAV for Unix libraries are installed

   fechomess 1 checking_libraries

   doLibCheck "libsavi" $libsavi

   [ "$isLinux" = "yes" ] && doSSPLibCheck "libssp" $libssp

   # Don't check if we think we have one - it may not be as expected

   if [ "$got_lib" != "yes" ]
   then
   ll=`ldd 2>/dev/null $savdid | grep "libsavi" | sed 's![^=]*=>[^/]*\([^ \t]*\)[ \t]*.*!\1!'`
   if [ "$ll" = "" ]; then
       ferror WrongLibsaviErr
   fi
   echo "libsavi: $ll"
   fi

   # Check virus data is installed.

   fechomess 1 checking_virus_data
   found_virus_data=$sav_install_dir
   if [ ! $existence_test $sav_install_dir/vdl.dat ]; then
     found_virus_data=
     # Couldn't find virus data in the SAV directory.
     # Try /usr/local/sav directory
     if [ $existence_test $sav_for_unix_virus_dir/vdl.dat ]; then
        found_virus_data=$sav_for_unix_virus_dir
     fi
     if [ "$config_file" ]; then
        config_sav_data_dir=
        # Get definition of SAV virus data dir from config file
        l=`egrep -i "^[ $tab]*sav[ $tab]*virus[ $tab]*[a-z]*[ $tab]*dir*[a-z]*" $config_file`
        test "$l" && config_sav_data_dir="`echo $l | sed -e 's/^.*= *//' -e 's/ *$//'`"
        if [ $existence_test $config_sav_data_dir/vdl.dat ]; then
          sav_install_dir=$config_sav_data_dir
          found_virus_data=$sav_install_dir
        fi
     fi

     # See if virus data is in peanut virus data area
     if [ "$sav5_possible" = "yes" ] && [ $existence_test $sav5_vdls/vdl.dat ]; then
       # Found virus data in peanut area.  As we have failed to find the virus
       # data in the sav install directory, we can set up symlinks across to
       # the peanut virus data, and use that.  If we reinstall virus data over
       # this, that should be okay.

     #  if [ ! -d "$sav_install_dir" ]; then
     #    VAmkdir "$sav_install_dir" 0755 0 0
     #  fi

       # Get list of peanut virus data
     #  vdls=`ls $peanut_vdls/vdl*`
     #  for v in $vdls; do
     #    if [ ! $existence_test $v ]; then
     #      ferror could_not_find_virus_data
     #    fi
     #    vname=`basename $v`
     #    echo $vname
     #    VAln $v $sav_install_dir/$vname
     #  done

       found_virus_data=$sav5_vdls
       sav5_vdl_found=yes # we found SAV 5 virus data

     fi

     # Check for a 64 bit version and allow it to override the
     # 32 bit if such had been found.

     if [ "$sav5_possible" = "yes" ] && [ $existence_test $sav5_vdls64/vdl.dat ]; then
       # Found virus data in 64 bits SAV location

       found_virus_data=$sav5_vdls64
       sav5_vdl_found=yes # we found SAV 5 virus data

     fi


     if [ "$found_virus_data" = "" ]; then
        ferror could_not_find_virus_data
     fi
   fi
   echo "Virus data: $found_virus_data"
   fecho 1
}

########

# Read in some of the more common messages so that these are output quickly.
# Things like "copied" are used quite frequently, so this saves us time.
# Also, we try to ensure we've got the messages output when we install the
# binaries, libraries, and the virus data so that that whole sequence of 
# events takes place reasonably quickly.
#
readSomeMessages()
{
  fechomess 1 reading_installation_text
  fecho 1
  getmess copied
  copiedText=$output
  getmess installing_binaries
  installing_binariesText=$output
  getmess binaries_will_be_installed
  binaries_will_be_installedText=$output
  getmess messages_will_be_installed 
  messages_will_be_installedText=$output
  getmess savid_will_be_installed
  savid_will_be_installedText=$output
  getmess installation_complete 
  installation_completeText=$output
  getmess savdid_conf_new
  savdid_conf_new=$output
}
########

informUser()
{
   if [ $verbose -gt 0 ]; then
      # Binaries will be installed in \'$bin_install_dir\'
      fechomess t "$binaries_will_be_installedText" "$bin_install_dir"
      if [ "$message_files" = yes ]; then
        # Message text will be installed in \'$savid_install_dir\'
        fechomess t "$messages_will_be_installedText" "$savid_install_dir"
      fi
     
      echo
      # State the blatantly obvious...
      # "SAVI daemon will be installed"
      fechomess t "$savid_will_be_installedText"
      fecho 1
   fi
}

########

installBinaries()
{
#  "===> Installing SAVI daemon"
   fechomess 1 t "$installing_binariesText"

   # Ensure the binary directory exists
   if [ ! -d "$bin_install_dir" ]; then
      VAmkdir "$bin_install_dir" 0755 0 0
   fi

   if [ -r savdid ]; then
     VAcp "savdid" $bin_install_dir/savdid 0755
   fi

   if [ -r savdid-i ]; then
     VAcp "savdid-i" $bin_install_dir/savdid-i 0755
   fi

   fecho 1
}

########

install_messages()
{
#  "===> Installing messages"
   fechomess 1 installing_messages

   if [ ! -d "$savid_install_dir" ]; then
      VAmkdir "$savid_install_dir" 0755 0 0
   fi

   # Copy SAVI daemon message files across
   for f in savdidlang*.txt; do
     if [ -r $f ]; then
       # savid - copy it into the /usr/local/savdi directory (for now)
       VAcp $f "$savid_install_dir/$f" 0644
       # and set up symlink into the bin directory
       # We were setting up a symlink into the bin directory but this should   
       # no longer be needed.
       #VAln $savid_install_dir/$f $bin_install_dir/$f
     fi
   done

   # Copy SAVI daemon configuration files across
   # This caters for files named savid.conf, savid.conf.sample, etc.
   for f in savdid.conf?*; do
     if [ -r $f ]; then
       VAcp $f "$savid_install_dir/$f" 0644
     fi
   done

   # Modify the savdid.conf to include the locations of the virusdata
   # found on this system

   sed -e 's!^#virusdatadir[ \t]*:.*$!virusdatadir: '$found_virus_data'!' \
       -e 's!^#idedir[ \t]*:.*$!idedir: '$found_virus_data'!' \
     <savdid.conf\
     >/var/tmp/savdid.conf

   if [ -d $savid_install_dir ] && [ -f $savid_install_dir/savdid.conf ]; then
     fechomess t "$savdid_conf_new"
     VAcp /var/tmp/savdid.conf "$savid_install_dir/savdid.conf.new" 0644
   else
     VAcp /var/tmp/savdid.conf "$savid_install_dir/savdid.conf" 0644
   fi
   rm /var/tmp/savdid.conf

   # DEF66987 - create /var/tmp/savdi/logs directory if not already present
   if [ ! -d /var/tmp/savdi/log ]; then
     mkdir -p /var/tmp/savdi/log > /dev/null 2> /dev/null
   fi

   # Prettification
   fecho 1
}

########

checkPaths()
{
   # prints the very final things after a successful installation.
   # In particular, prints warning messages if the path where the binaries
   # and/or the libraries are installed is not in the path or the library
   # path.
   #
   # Also prints final platform specific messages where appropriate.
   #
   # Arguments: none
   # Returns:   0 if okay, non zero if any problems found with paths
   #
#  "===> Checking paths are accessible"
   fechomess 1 checking_paths

   case $PATH in
   $bin_install_dir | $bin_install_dir:* | *:$bin_install_dir | *:$bin_install_dir:*)
#     "'$PATH' is OK"
      fechomess 1 + path_ok;;
   *) # "Warning: \$PATH does not include $bin_install_dir"
      fechomess - path_not_bin $bin_install_dir
      finalWarning=yes
      # "To run the SAVI daemon you need to set environment variable \$PATH so that it includes $bin_install_dir."
      fechomess 1 + path_config "$bin_install_dir"
      fecho 1
   esac

   if [ "$savid_doesnt_look_for_vdl" = "yes" ] && [ "$sav5_vdl_found" != "" ]; then
      # "Warning: virus data has been found at $1.  You may need to amend the SAVI daemon configuration file (savid.conf) otherwise the SAVI daemon may not be able to find the virus data."
      fechomess - virus_data_location $found_virus_data
      fechomess 1 + virus_data_conf
   fi

   if [ "$finalWarning" ]; then
      if [ $verbose -eq 0 ]; then
         # "If you need more details on these settings, run install with the -v option."
         fechomess settings_more_details
      else
         # "Some environment variables may need to be set on your system. To make these settings permanent, add them to your login script or profile\; to make these settings systemwide, amend /etc/login or /etc/profile."
         fechomess some_env_vars_need_setting
      fi
      fecho 1
   fi

   return 
}

########

#########################
##                     ##
##  START, BEGIN, GO   ##
##                     ##
#########################

LC_COLLATE=C            # C/POSIX locale; use basic ASCII collating sequence
p=${0%/*}; 
[ "$p" ] && cd "$p"     # in case wd is not that which contains this script

declareInitVariables    # all variables are declared here, possibly initialised
scanCommandLine "$@"    # reads command line parameters and adjusts some variables accordingly
                        # however, does not output error messages until we
                        # determine language, below.

detectPlatform          # finds out which OS and adjusts some variables accordingly

detectCompatibility     # basic compatibility

detectLanguage          # try to establish which language we are running in

# "Sophos Anti-Virus installation utility [$product_name]"
fechomess Title "[$product_name]"
# "Copyright (c) 1998-2015 Sophos Ltd, Oxford, England"
fechomess Copyright
echo
reportEarlyErrors       # report any errors or help that occurred before title

readSomeMessages        # read in some of the common messages
doAllPossibleChecks  # does all checks possible before trying to actually install
informUser
installBinaries
install_messages

# All's well.
checkPaths
# "===> Installation complete <==="
fechomess 1 t "$installation_completeText"
VAexit 0
