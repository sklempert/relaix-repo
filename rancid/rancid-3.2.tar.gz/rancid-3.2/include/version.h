#ifndef VERSION_H

#define VERSION_H

/* pkg version */
char package[] = "rancid";
char version[] = "3.2";

#endif
